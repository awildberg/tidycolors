pillar 1.11.1

## Cran Repository Policy

- [x] Reviewed CRP last edited 2024-08-27.
