pillar 1.11.0

## Cran Repository Policy

- [x] Reviewed CRP last edited 2024-08-27.
