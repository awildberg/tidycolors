# output test

    Code
      pillar(add_special(c(TRUE, FALSE)))
    Output
      <pillar>
      <lgl>
      TRUE 
      FALSE
      NA   

